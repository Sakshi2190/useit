﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Dispatcher;
using System.Text;
using System.Xml;
using System.Xml.Linq;

namespace FH.CVC.Calendar.CustomBindings
{
    public class GraphAPIResponseHandler : IErrorHandler
    {
        public bool HandleError(Exception error)
        {
            return true;
        }
        public void ProvideFault(Exception error, MessageVersion version, ref Message fault)
        {
            bool webException = false;

            if (error is WebException)
            {
                //get http resopnse status from WebException
                WebException wex = (WebException)(error);
                if (wex.Status == WebExceptionStatus.ProtocolError)
                {
                    var response = wex.Response as HttpWebResponse;
                    if (response != null && response.StatusCode == HttpStatusCode.NotFound)
                    {
                        webException = true;

                    }
                }
            }
            //XDocument errorMsg = XDocument.Parse(error.Message);
            HttpResponseMessageProperty prop = new HttpResponseMessageProperty();
            //prop.Headers[HttpResponseHeader.ContentType] = "application/json; charset=utf-8";
            //get the HTTP status code
            //prop.StatusCode = (HttpStatusCode)int.Parse(errorMsg.Root.Element("StatusCode").Value);
            //this doesn't need to be included in the message
            //errorMsg.Root.Element("StatusCode").Remove();
            fault = Message.CreateMessage(version, null);
            fault.Properties.Add(HttpResponseMessageProperty.Name, prop);
           // fault.Properties.Add(WebBodyFormatMessageProperty.Name, new WebBodyFormatMessageProperty(WebContentFormat.Json));
        }
    }

}
