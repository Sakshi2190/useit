﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel.Configuration;
using System.Text;
using System.Threading.Tasks;

namespace FH.CVC.Calendar.CustomBindings
{
    class JsonFaultBehaviorElement : BehaviorExtensionElement
    {
        public override Type BehaviorType
        {
            get { return typeof(JsonFaultBehavior); }
        }
        protected override object CreateBehavior()
        {
            return new JsonFaultBehavior();
        }

    }
}